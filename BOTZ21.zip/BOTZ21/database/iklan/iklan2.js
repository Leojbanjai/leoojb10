const iklan2 = () => {
	return `[ YOUR IKLAN ]`
}

exports.iklan2 = iklan2