const iklan3 = () => {
	return `[ YOUR IKLAN ]`
}

exports.iklan3 = iklan3